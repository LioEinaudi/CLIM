"""Reproduce the unmodified commit in a normal host Python environment.

Install the supplied exact dependencies and CLIM checkout before invoking.
Use a fresh output directory because the upstream recorder is append-only.
"""
import argparse
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from importlib.metadata import version
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--repo", type=Path, required=True)
p.add_argument("--output", type=Path, required=True)
args = p.parse_args()
repo, out = args.repo.resolve(), args.output.resolve()
pilot = repo / "benchmarks/framework_pilot"
out.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env.update(OTEL_SDK_DISABLED="true", CREWAI_DISABLE_TELEMETRY="true")
records = []


def digest(path):
    path = Path(path)
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def run(label, argv, cwd):
    start = time.monotonic()
    with (out / (label + ".log")).open("w") as log:
        result = subprocess.run(argv, cwd=cwd, env=env, stdout=log,
                                stderr=subprocess.STDOUT, timeout=60)
    entry = {"label": label, "argv": argv, "cwd": str(cwd),
             "exit_code": result.returncode, "elapsed_seconds": time.monotonic() - start}
    records.append(entry)
    (out / "commands.json").write_text(json.dumps(records, indent=2) + "\n")
    print(label, "exit", result.returncode, "seconds", round(entry["elapsed_seconds"], 3), flush=True)
    result.check_returncode()


commit = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert commit == "4e4b75f858e05857825a1450417d899dbf19ec42", commit
subprocess.run(["git", "diff", "--exit-code", "HEAD"], cwd=repo, check=True)
contract_hashes = {str(path.relative_to(repo)): digest(path) for path in
                   (repo / "contracts/file_delete.json", pilot / "contracts/file_delete.json")}
assert len(set(contract_hashes.values())) == 1
outside = ["/etc/passwd", "/tmp/outside.txt"]
info = {"started_utc": datetime.now(timezone.utc).isoformat(), "python": platform.python_version(),
        "os": platform.platform(), "packages": {name: version(name) for name in
            ("clim-agent-guard", "langgraph", "crewai", "openai", "pytest")},
        "commit": commit, "tracked_source_unmodified": True, "source": "fixture", "model_calls": 0,
        "execution_environment": "normal host, temporary-file executor sandbox",
        "outside_files_before": {path: digest(path) for path in outside},
        "contract_hashes": contract_hashes,
        "telemetry_env": {k: env[k] for k in ("OTEL_SDK_DISABLED", "CREWAI_DISABLE_TELEMETRY")}}
(out / "environment.json").write_text(json.dumps(info, indent=2) + "\n")
py = sys.executable
run("pip_check", [py, "-m", "pip", "check"], repo)
run("pytest_core", [py, "-m", "pytest", "-q", "tests"], repo)
run("pytest_pilot", [py, "-m", "pytest", "-q", "tests"], pilot)
for framework, prefix in (("langgraph", "lg"), ("crewai", "crew")):
    run(prefix + "_smoke", [py, "-m", "pilot.run_" + framework + "_matrix",
        "--source", "fixture", "--repeats", "1", "--output", str(out / (prefix + "_smoke.jsonl"))], pilot)
    run(prefix + "_fixture", [py, "-m", "pilot.run_" + framework + "_matrix",
        "--source", "fixture", "--repeats", "20", "--output", str(out / (prefix + "_fixture.jsonl"))], pilot)
matrix = [str(out / (prefix + "_fixture.jsonl")) for prefix in ("lg", "crew")]
run("metrics", [py, "-m", "pilot.metrics", "--input", *matrix,
    "--json-out", str(out / "fixture_scores.json"), "--csv-out", str(out / "fixture_scores.csv")], pilot)
run("export_phase1", [py, "-m", "pilot.export_phase1", "--input", *matrix,
    "--output", str(out / "phase1_input.jsonl")], pilot)
run("offline_audit", [py, "-m", "clim_agent_guard.audit", "--input", str(out / "phase1_input.jsonl"),
    "--contract", str(repo / "contracts/file_delete.json"), "--output", str(out / "offline_assessment.json")], repo)
with (out / "environment_freeze.txt").open("w") as f:
    subprocess.run([py, "-m", "pip", "freeze"], stdout=f, check=True)
info["outside_files_after"] = {path: digest(path) for path in outside}
assert info["outside_files_after"] == info["outside_files_before"]
info["finished_utc"] = datetime.now(timezone.utc).isoformat()
(out / "environment.json").write_text(json.dumps(info, indent=2) + "\n")
